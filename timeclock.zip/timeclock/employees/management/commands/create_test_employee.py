from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from employees.models import Employee

class Command(BaseCommand):
    help = 'Creates a default test employee'

    def handle(self, *args, **options):
        # Create test user
        user, created = User.objects.get_or_create(
            username='testemployee',
            defaults={
                'first_name': 'Test',
                'last_name': 'Employee',
                'email': 'test@example.com',
                'is_active': True
            }
        )
        
        if created:
            user.set_password('testpass123')
            user.save()
            self.stdout.write(self.style.SUCCESS('Created test user'))
        
        # Create employee profile
        employee, emp_created = Employee.objects.get_or_create(
            user=user,
            defaults={
                'hourly_rate': 15.00
            }
        )
        
        if emp_created:
            self.stdout.write(self.style.SUCCESS('Created test employee with hourly rate $15.00'))
        else:
            self.stdout.write(self.style.WARNING('Test employee already exists'))