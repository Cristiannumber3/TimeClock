from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from .models import Employee, TimeLog
from .forms import EmployeeForm, UserForm

def login_view(request):
    # If user is already authenticated, redirect to home
    if request.user.is_authenticated:
        return redirect('home')
    
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            next_url = request.GET.get('next', 'home')  # Handle 'next' parameter if exists
            return redirect(next_url)
        else:
            messages.error(request, 'Invalid username or password')
    
    return render(request, 'employees/login.html')

def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def home(request):
    try:
        employee = request.user.employee
    except Employee.DoesNotExist:
        # If user doesn't have an employee profile, log them out
        logout(request)
        messages.error(request, 'No employee profile exists for this user')
        return redirect('login')
    
    # Check if user is currently clocked in
    current_log = TimeLog.objects.filter(employee=employee, clock_out__isnull=True).first()
    
    context = {
        'employee': employee,
        'clocked_in': current_log is not None,
    }
    return render(request, 'employees/home.html', context)

@login_required
def clock_in_out(request):
    employee = request.user.employee
    
    # Get current active time log (if exists)
    current_log = TimeLog.objects.filter(employee=employee, clock_out__isnull=True).first()
    
    if request.method == 'POST':
        if current_log:
            # Clock out
            current_log.clock_out = timezone.now()
            current_log.save()
            messages.success(request, f'Successfully clocked out at {current_log.clock_out}')
        else:
            # Clock in
            TimeLog.objects.create(employee=employee)
            messages.success(request, 'Successfully clocked in')
        
        return redirect('home')
    
    context = {
        'clocked_in': current_log is not None,
    }
    return render(request, 'employees/clock_in_out.html', context)

@login_required
def payroll(request):
    employee = request.user.employee
    time_logs = TimeLog.objects.filter(employee=employee).order_by('-clock_in')
    
    # Calculate totals
    total_seconds = sum(
        (log.clock_out - log.clock_in).total_seconds() 
        for log in time_logs 
        if log.clock_out
    )
    total_hours = total_seconds / 3600
    total_pay = total_hours * float(employee.hourly_rate)
    
    context = {
        'time_logs': time_logs,
        'total_hours': round(total_hours, 2),
        'total_pay': round(total_pay, 2),
        'employee': employee,
    }
    return render(request, 'employees/payroll.html', context)

@login_required
def add_employee(request):
    # Only superusers can add employees
    if not request.user.is_superuser:
        messages.error(request, 'You do not have permission to add employees')
        return redirect('home')
    
    if request.method == 'POST':
        user_form = UserForm(request.POST)
        employee_form = EmployeeForm(request.POST)
        
        if user_form.is_valid() and employee_form.is_valid():
            # Create the user
            user = user_form.save(commit=False)
            user.set_password(user_form.cleaned_data['password1'])
            user.save()
            
            # Create the employee profile
            employee = employee_form.save(commit=False)
            employee.user = user
            employee.save()
            
            messages.success(request, f'Employee {user.username} added successfully')
            return redirect('home')
    else:
        user_form = UserForm()
        employee_form = EmployeeForm()
    
    context = {
        'user_form': user_form,
        'employee_form': employee_form,
    }
    return render(request, 'employees/add_employee.html', context)