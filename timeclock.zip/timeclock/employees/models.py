from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class Employee(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    hourly_rate = models.DecimalField(max_digits=6, decimal_places=2)
    
    def __str__(self):
        return self.user.get_full_name() or self.user.username

class TimeLog(models.Model):
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    clock_in = models.DateTimeField(default=timezone.now)
    clock_out = models.DateTimeField(null=True, blank=True)
    
    def duration(self):
        if self.clock_out:
            return self.clock_out - self.clock_in
        return timezone.now() - self.clock_in
    
    def is_clocked_in(self):
        return self.clock_out is None
    
    class Meta:
        ordering = ['-clock_in']