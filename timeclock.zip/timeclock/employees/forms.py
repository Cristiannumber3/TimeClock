from django import forms
from .models import Employee, TimeLog
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class EmployeeForm(forms.ModelForm):
    class Meta:
        model = Employee
        fields = ['hourly_rate']

class UserForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'password1', 'password2']

class TimeLogForm(forms.ModelForm):
    class Meta:
        model = TimeLog
        fields = []